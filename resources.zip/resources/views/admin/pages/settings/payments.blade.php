@extends('admin.layouts.admin_app')

@section('content')

payments settings

@push('scripts')
<script></script>
@endpush
@endsection